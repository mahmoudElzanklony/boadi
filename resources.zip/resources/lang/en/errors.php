<?php

return [
  'image_error'=>'please upload valid extension for image like jpeg or png or jpg or gif',
  'unauthenticated'=>'phone number or password is not correct',
    'unauthenticated_serial'=>'phone number of serial code is not correct',
    'error_upload_image'=>'Uploaded error file must be an image',
    'unauthorized'=>'you are unauthorized to do this action',
    'payment_before'=>'This Ad has been paid before',
    'payment_unauthorized_user'=>'you are not the owner of this ad',
    'not_enough_points'=>'Not enough points',

];
