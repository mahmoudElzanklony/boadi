<?php

return [
    'registered_user'=>'Register operation has been done successfully',
    'err_invalid_type'=>'error at user type',
    'unauthenticated_err_form'=>'Error at email or password',
    'updated_successfully'=>'Updated operation done successfully',
    'saved_successfully'=>'Operation done successfully',
    'deleted_successfully'=>'Delete operation done successfully',
    'removed_from_fav_successfully'=>'removed from favourite has done successfully',
    'added_to_fav_successfully'=>'adding to favourite has done successfully',
    'saved_new_user'=>'Saved new user successfully',

];
